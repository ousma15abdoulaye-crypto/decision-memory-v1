# CBA TEMPLATE MAPPING ENGINE — V1.0

(voir template_spec_v1.0.json + code src/mapping)
